function love.conf(t)
    t.modules.joystick = false
    t.modules.physics = false
    t.externalstorage = true
    t.version = "11.5"

    -- أضف هذا السطر فقط للتأكيد البرمجي
    t.window.display = 0 
end